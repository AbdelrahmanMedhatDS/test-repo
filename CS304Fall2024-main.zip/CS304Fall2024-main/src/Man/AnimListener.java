/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Man;

import java.awt.event.KeyListener;
import javax.media.opengl.GLEventListener;

/**
 *
 * @author Tyba
 */

public abstract class AnimListener implements GLEventListener, KeyListener {
 
    protected String assetsFolderName = "Assets//Man";
    
}
